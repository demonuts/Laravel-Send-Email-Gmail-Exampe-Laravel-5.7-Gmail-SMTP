<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;

class SendGmailController extends Controller
{
    //
    public function sendgmail()
    {
        $data = array('name'=>"Sam Jose", "body" => "Test mail");
    
        Mail::send('gmailview', $data, function($message) {
            $message->to('johndoesense12@gmail.com', 'John Doe')
            ->subject('From Laravel With Gmail');
            $message->from('jesalmithani15@gmail.com',' Jesal Mithani');

          });

          if (Mail::failures()) {
            return response()->Fail('Sorry! Please try again latter');
          }else{
            return response()->json('Yes, You have sent email to GMAIL from LARAVEL !!');
          }
   }
}
